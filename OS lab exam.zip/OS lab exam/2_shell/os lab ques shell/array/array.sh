#!/bin/bash

echo -e "ARRAY\n"

arr1=("a" "b" "c")

echo -e "elements in array are : ${arr1[@]}\n"