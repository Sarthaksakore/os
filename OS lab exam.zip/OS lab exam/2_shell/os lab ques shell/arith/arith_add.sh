#!/bin/bash

echo "Enter 1st number"
read n1
echo "Enter 2nd number"
read n2
add=$[$n1+$n2]
echo "Addition : $n1 + $n2 = $add"
