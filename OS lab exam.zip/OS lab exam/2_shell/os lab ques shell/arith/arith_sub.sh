#!/bin/bash

echo "Enter 1st number"
read n1
echo Enter 2nd number
read n2
sub=$(($n1-$n2))
echo Subtraction : $n1 - $n2 = $sub