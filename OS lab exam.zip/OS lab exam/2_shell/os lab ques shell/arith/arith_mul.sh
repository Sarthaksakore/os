#!/bin/bash

echo Enter 1st number
read n1
echo Enter 2nd number
read n2
mul=$[$n1*$n2]
echo Multiplication : $n1 x $n2 = $mul