#!/bin/bash

echo alias for printing hello

alias hello='echo hey'

alias hello