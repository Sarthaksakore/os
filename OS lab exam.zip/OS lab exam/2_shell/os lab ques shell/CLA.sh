#!/bin/bash

echo "average of 3 nums using  CLA"

((avg=($1+$2+$3)/3))
echo "average is $avg"