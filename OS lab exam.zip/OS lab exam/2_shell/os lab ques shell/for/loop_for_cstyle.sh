#!/bin/bash

echo PRINT EVEN NUMBERS FROM 1-10 USING C-STYLED FOR LOOP

for((i=2;i<=10;i+=2));
    do
        echo $i
    done